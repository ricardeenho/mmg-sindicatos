-- MMG Sindicatos - instalacao completa do modulo de assinatura por QR + gerentes de unidade
-- Pode ser executado mesmo se parte das migrations anteriores ja tiver sido aplicada.
-- Nao apaga requisicoes, usuarios nem assinaturas existentes.

-- 1) Assinaturas das requisicoes
create table if not exists public.requisicao_assinaturas (
  id uuid primary key default gen_random_uuid(),
  requisicao_id uuid not null references public.requisicoes(id) on delete cascade,
  usuario_id uuid not null references public.usuarios(id) on delete restrict,
  token_hash text not null,
  status text not null default 'pendente',
  expira_em timestamptz not null,
  document_hash text not null,
  document_snapshot jsonb not null,
  validation_code text,
  criado_por text,
  criado_em timestamptz not null default now(),
  assinada_em timestamptz,
  ip_assinatura text,
  navegador_assinatura text
);

-- Completa uma instalacao parcial, caso a tabela ja existisse.
alter table public.requisicao_assinaturas
  add column if not exists validation_code text,
  add column if not exists criado_por text,
  add column if not exists criado_em timestamptz not null default now(),
  add column if not exists assinada_em timestamptz,
  add column if not exists ip_assinatura text,
  add column if not exists navegador_assinatura text;

alter table public.requisicao_assinaturas
  drop constraint if exists requisicao_assinaturas_status_check;

alter table public.requisicao_assinaturas
  add constraint requisicao_assinaturas_status_check
  check (status in ('pendente', 'assinada', 'cancelada'));

create unique index if not exists uq_requisicao_assinaturas_validation_code
  on public.requisicao_assinaturas (validation_code)
  where validation_code is not null;

create index if not exists idx_requisicao_assinaturas_requisicao
  on public.requisicao_assinaturas (requisicao_id, criado_em desc);

create index if not exists idx_requisicao_assinaturas_usuario
  on public.requisicao_assinaturas (usuario_id, status, expira_em);

create unique index if not exists uq_requisicao_assinatura_pendente
  on public.requisicao_assinaturas (requisicao_id, usuario_id)
  where status = 'pendente';

-- O frontend nunca acessa esta tabela diretamente; quem acessa e o backend PostgreSQL.
alter table public.requisicao_assinaturas enable row level security;

-- 2) Conta de gerente exclusiva para assinatura
alter table public.usuarios
  add column if not exists somente_assinatura boolean not null default false;

-- 3) Cada unidade possui um gerente responsavel; um gerente pode responder por varias unidades.
create table if not exists public.unidade_gerentes (
  unidade_id uuid primary key references public.unidades(id) on delete cascade,
  usuario_id uuid not null references public.usuarios(id) on delete cascade,
  criado_por text,
  criado_em timestamptz not null default now()
);

create index if not exists idx_unidade_gerentes_usuario
  on public.unidade_gerentes (usuario_id);

alter table public.unidade_gerentes enable row level security;

comment on table public.unidade_gerentes is
  'Gerente responsavel por assinar requisicoes de cada unidade. Um gerente pode responder por varias unidades.';

comment on column public.usuarios.somente_assinatura is
  'Quando true, o usuario pode usar apenas rotas de assinatura e troca da propria senha.';
