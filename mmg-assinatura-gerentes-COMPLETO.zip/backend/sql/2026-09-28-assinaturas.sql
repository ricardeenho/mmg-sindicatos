-- Assinatura de requisições por usuário + token de uso único.
-- Rode este arquivo uma vez no SQL Editor do Supabase antes de subir o backend novo.

create table if not exists requisicao_assinaturas (
  id uuid primary key default gen_random_uuid(),
  requisicao_id uuid not null references requisicoes(id) on delete cascade,
  usuario_id uuid not null references usuarios(id) on delete restrict,

  -- Nunca guardar o token puro: somente SHA-256 hexadecimal.
  token_hash text not null,
  status text not null default 'pendente'
    check (status in ('pendente', 'assinada', 'cancelada')),
  expira_em timestamptz not null,

  -- Congela a versão da requisição que o usuário está aceitando.
  document_hash text not null,
  document_snapshot jsonb not null,

  validation_code text unique,
  criado_por text,
  criado_em timestamptz not null default now(),
  assinada_em timestamptz,
  ip_assinatura text,
  navegador_assinatura text
);

create index if not exists idx_requisicao_assinaturas_requisicao
  on requisicao_assinaturas (requisicao_id, criado_em desc);

create index if not exists idx_requisicao_assinaturas_usuario
  on requisicao_assinaturas (usuario_id, status, expira_em);

-- Uma pessoa não precisa receber duas solicitações pendentes simultâneas
-- para a mesma requisição. Expirada pode ser cancelada/limpa ou substituída
-- depois de mudar seu status para cancelada.
create unique index if not exists uq_requisicao_assinatura_pendente
  on requisicao_assinaturas (requisicao_id, usuario_id)
  where status = 'pendente';
