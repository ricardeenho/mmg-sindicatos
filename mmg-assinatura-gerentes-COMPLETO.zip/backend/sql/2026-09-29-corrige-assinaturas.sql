-- Hotfix idempotente para o modulo de assinatura.
-- Pode ser executado mais de uma vez sem apagar assinaturas existentes.

alter table public.requisicao_assinaturas
  add column if not exists validation_code text,
  add column if not exists criado_por text,
  add column if not exists criado_em timestamptz not null default now(),
  add column if not exists assinada_em timestamptz,
  add column if not exists ip_assinatura text,
  add column if not exists navegador_assinatura text;

-- Garante que o status usado ao confirmar a assinatura seja aceito.
alter table public.requisicao_assinaturas
  drop constraint if exists requisicao_assinaturas_status_check;

alter table public.requisicao_assinaturas
  add constraint requisicao_assinaturas_status_check
  check (status in ('pendente', 'assinada', 'cancelada'));

create unique index if not exists uq_requisicao_assinaturas_validation_code
  on public.requisicao_assinaturas (validation_code)
  where validation_code is not null;

create index if not exists idx_requisicao_assinaturas_requisicao
  on public.requisicao_assinaturas (requisicao_id, criado_em desc);

create index if not exists idx_requisicao_assinaturas_usuario
  on public.requisicao_assinaturas (usuario_id, status, expira_em);
