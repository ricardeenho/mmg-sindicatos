-- Vincula cada unidade ao gerente que deve assinar suas requisicoes.
-- Idempotente: pode ser executada mais de uma vez.

alter table public.usuarios
  add column if not exists somente_assinatura boolean not null default false;

create table if not exists public.unidade_gerentes (
  unidade_id uuid primary key references public.unidades(id) on delete cascade,
  usuario_id uuid not null references public.usuarios(id) on delete cascade,
  criado_por text,
  criado_em timestamptz not null default now()
);

create index if not exists idx_unidade_gerentes_usuario
  on public.unidade_gerentes (usuario_id);

-- A tabela nao deve ser manipulada diretamente pelo frontend/Supabase client.
-- O backend usa a conexao PostgreSQL do Railway e faz as validacoes.
alter table public.unidade_gerentes enable row level security;

comment on table public.unidade_gerentes is
  'Gerente responsavel por assinar requisicoes de cada unidade. Um gerente pode responder por varias unidades.';
comment on column public.usuarios.somente_assinatura is
  'Quando true, o usuario pode usar apenas rotas de assinatura e troca da propria senha.';
